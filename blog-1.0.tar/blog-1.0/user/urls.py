from django.conf.urls import url
from .views import reg, test, login


urlpatterns = [
    # 下面三个有一个即可
    url(r'^$', reg),
    url(r'^test$', test),
    url(r'^login$', login)
    ]
