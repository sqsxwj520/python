print(__name__, "~~~~~~~~~~")
abc = 100
